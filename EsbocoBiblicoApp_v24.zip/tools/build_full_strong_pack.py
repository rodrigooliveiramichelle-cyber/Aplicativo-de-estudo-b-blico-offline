#!/usr/bin/env python3
"""Reproducible Strong build: JFAA -> STEPBible -> assets -> validation -> gaps."""
from __future__ import annotations
import argparse, shutil, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
ASSET=ROOT/"app/src/main/assets"
CACHE=ROOT/"tools/stepbible_cache"
def run(script, extra=()):
    print(f"\n=== {script.name} ===")
    r=subprocess.run([sys.executable,str(script),*map(str,extra)],cwd=ROOT)
    if r.returncode: raise SystemExit(r.returncode)
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--jfaa",required=True)
    ap.add_argument("--ref",default="master")
    ap.add_argument("--force-download",action="store_true")
    args=ap.parse_args()
    run(ROOT/"tools/validate_jfaa.py",[args.jfaa])
    fetch=["--ref",args.ref]
    if args.force_download: fetch.append("--force")
    run(ROOT/"tools/fetch_stepbible_sources.py",fetch)
    # Build must consume the fetched cache; it must never silently redownload a
    # different revision.
    run(ROOT/"tools/build_strong_db.py",["--ref",args.ref])
    run(ROOT/"tools/validate_strong_pack.py")
    run(ROOT/"tools/report_strong_gaps.py")
    print("\nBUILD COMPLETO: JFAA -> fontes STEPBible -> Strong -> validação -> lacunas.")
if __name__=="__main__": main()
