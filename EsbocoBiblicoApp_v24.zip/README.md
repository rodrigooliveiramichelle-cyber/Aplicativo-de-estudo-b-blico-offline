# Esboço Bíblico Offline — V24

Projeto Android Kotlin + WebViewAssetLoader, com a Bíblia JFAA fornecida pelo usuário embutida localmente e infraestrutura para dados Strong offline.

## V24 — avanço desta versão
- O construtor agora **valida primeiro o JSON JFAA real** e registra SHA-256 e a lista exata de referências.
- A contagem da JFAA fornecida foi verificada neste projeto: **66 livros e 31.104 versículos**.
- O downloader Strong descobre os 8 arquivos no repositório oficial e agora possui fallback pela Git Blob API para arquivos grandes: descobre os 8 arquivos no **GitHub oficial STEPBible-Data** pela árvore do repositório.
- Aceita `--ref` para fixar branch, tag ou commit.
- Gera manifesto com caminho, tamanho e SHA-256 de cada fonte.
- `build_full_strong_pack.py` agora executa a cadeia completa: JFAA → fontes STEPBible → tokens/léxico → validação → relatório de lacunas.
- O aplicativo continua offline depois que os assets Strong forem gerados e incluídos em `app/src/main/assets/`.

## Construção da base Strong completa
Em uma máquina com Python 3 e internet:

```bash
python3 tools/build_full_strong_pack.py --jfaa "/caminho/JFAA - Almeida Atualizada (1).json" --ref master
```

Para reprodutibilidade, fixe uma referência do repositório:

```bash
python3 tools/build_full_strong_pack.py --jfaa "/caminho/JFAA - Almeida Atualizada (1).json" --ref master --ref master
```

O projeto não afirma que a base Strong completa já está embutida no ZIP. Ela só deve ser considerada completa depois que o processo terminar e o `validate_strong_pack.py` confirmar os arquivos gerados.

## Fontes e licença
Os dados TAGNT/TAHOT e TBESG/TBESH são provenientes do STEPBible-Data, disponibilizado sob CC BY 4.0. A atribuição deve ser mantida no aplicativo e nos arquivos derivados.

Fonte oficial: https://github.com/STEPBible/STEPBible-Data

## V24 — construção reprodutível
- O `build_strong_db.py` não baixa mais dados silenciosamente: ele consome exclusivamente o cache produzido pelo downloader.
- O `build_full_strong_pack.py` passa explicitamente a revisão escolhida ao construtor.
- O downloader tenta Raw GitHub e usa a Git Blob API como fallback para arquivos grandes.
- O manifesto registra o SHA-256 de cada fonte e a revisão do repositório.
- Isso reduz o risco de montar uma base parcialmente baixada ou misturar revisões diferentes.
