#!/usr/bin/env python3
"""Validate the supplied JFAA JSON and produce an exact reference manifest."""
from __future__ import annotations
import argparse, hashlib, json, sys
from pathlib import Path

EXPECTED_BOOKS = 66
EXPECTED_VERSES = 31104

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('json_path', help='JFAA JSON file')
    ap.add_argument('--out', default='tools/jfaa_manifest.json')
    args = ap.parse_args()
    p = Path(args.json_path)
    try:
        data = json.loads(p.read_text(encoding='utf-8'))
    except Exception as e:
        print(f'JFAA inválida: {e}', file=sys.stderr); return 2
    if not isinstance(data, list) or len(data) != EXPECTED_BOOKS:
        print(f'Livros: {len(data) if isinstance(data,list) else 0}/{EXPECTED_BOOKS}', file=sys.stderr); return 3
    refs=[]; bad=[]
    for bi, book in enumerate(data, 1):
        if not isinstance(book, dict) or not isinstance(book.get('chapters'), list):
            bad.append(f'book[{bi}]'); continue
        abbrev = str(book.get('abbrev','')).strip()
        for ci, chapter in enumerate(book['chapters'], 1):
            if not isinstance(chapter, list): bad.append(f'{abbrev}.{ci}'); continue
            for vi, text in enumerate(chapter, 1):
                refs.append(f'{abbrev}.{ci}.{vi}')
    digest = hashlib.sha256(p.read_bytes()).hexdigest()
    manifest={'source_file':p.name,'sha256':digest,'books':len(data),'verses':len(refs),'references':refs}
    out=Path(args.out); out.parent.mkdir(parents=True,exist_ok=True); out.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    print(f'JFAA: {len(data)} livros; {len(refs)} versículos; SHA-256 {digest}')
    if bad: print('Estruturas inválidas:', ', '.join(bad[:20]), file=sys.stderr); return 4
    if len(refs) != EXPECTED_VERSES:
        print(f'Atenção: contagem diferente do esperado: {len(refs)}/{EXPECTED_VERSES}', file=sys.stderr); return 5
    return 0
if __name__=='__main__': raise SystemExit(main())
