#!/usr/bin/env python3
"""Generate a chapter/verse gap report from installed Strong tokens and JFAA.

This compares the embedded JFAA verse inventory with token references. It does
not infer or create word-to-Strong alignment for the JFAA translation.
"""
from __future__ import annotations
import json,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
HTML=ROOT/'app/src/main/assets/esboco_biblico.html'
TOK=ROOT/'app/src/main/assets/strong_tokens.json'
OUT=ROOT/'strong_gap_report.txt'
s=HTML.read_text(encoding='utf-8')
m=re.search(r'const localBibleData = (\[.*?\]);\s*\n',s,re.S)
if not m: raise SystemExit('localBibleData não encontrado')
bible=json.loads(m.group(1)); tokens=json.loads(TOK.read_text(encoding='utf-8')) if TOK.exists() else {}
source_to_jfaa={'Gen':'Gn','Exo':'Êx','Lev':'Lv','Num':'Nm','Deu':'Dt','Jos':'Js','Jdg':'Jz','Rut':'Rt','1Sa':'1Sm','2Sa':'2Sm','1Ki':'1Rs','2Ki':'2Rs','1Ch':'1Cr','2Ch':'2Cr','Ezr':'Ed','Neh':'Ne','Est':'Et','Job':'Jó','Psa':'Sl','Pro':'Pv','Ecc':'Ec','Sng':'Ct','Isa':'Is','Jer':'Jr','Lam':'Lm','Eze':'Ez','Dan':'Dn','Hos':'Os','Joe':'Jl','Amo':'Am','Oba':'Ob','Jon':'Jn','Mic':'Mq','Nah':'Na','Hab':'Hc','Zep':'Sf','Hag':'Ag','Zec':'Zc','Mal':'Ml','Mat':'Mt','Mar':'Mc','Luk':'Lc','Jhn':'Jo','Act':'At','Rom':'Rm','1Co':'1Co','2Co':'2Co','Gal':'Gl','Eph':'Ef','Php':'Fp','Col':'Cl','1Th':'1Ts','2Th':'2Ts','1Ti':'1Tm','2Ti':'2Tm','Tit':'Tt','Phm':'Fm','Heb':'Hb','Jas':'Tg','1Pe':'1Pe','2Pe':'2Pe','1Jn':'1Jo','2Jn':'2Jo','3Jn':'3Jo','Jud':'Jd','Rev':'Ap'}
keys=set()
for k in tokens:
    if k=='_meta': continue
    m=re.match(r'^([A-Za-z0-9]+)\.(\d+)\.(\d+)$',k)
    if m: keys.add(f'{source_to_jfaa.get(m.group(1),m.group(1))}.{m.group(2)}.{m.group(3)}')
    else:
        m2=re.match(r'^(.+?)\s+(\d+):(\d+)$',k)
        names={'João':'Jo','Mateus':'Mt','Marcos':'Mc','Lucas':'Lc','Gênesis':'Gn','Êxodo':'Êx'}
        if m2: keys.add(f'{names.get(m2.group(1),m2.group(1))}.{m2.group(2)}.{m2.group(3)}')
        else: keys.add(k)
lines=['RELATÓRIO DE COBERTURA STRONG — V22','']
total=have=0
for b in bible:
    refs=covered=0; gaps=[]
    for ci,ch in enumerate(b.get('chapters',[]),1):
        for vi,_ in enumerate(ch,1):
            refs+=1; total+=1
            r=f"{b.get('abbrev')}.{ci}.{vi}"
            if r in keys or f"{b.get('abbrev')} {ci}:{vi}" in keys: covered+=1; have+=1
            else: gaps.append(f'{ci}:{vi}')
    pct=covered/refs*100 if refs else 0
    lines.append(f"{b.get('name',b.get('abbrev'))} ({b.get('abbrev')}): {covered}/{refs} ({pct:.2f}%)")
    if gaps: lines.append('  Lacunas: '+', '.join(gaps))
lines[2:2]=[f'Referências JFAA: {total}',f'Com tokens: {have}',f'Sem tokens: {total-have}',f'Cobertura: {have/total*100:.2f}%' if total else 'Cobertura: 0.00%','']
OUT.write_text('\n'.join(lines)+'\n',encoding='utf-8')
print(f'Gerado: {OUT}')
print(f'Referências: {total} | com tokens: {have} | sem tokens: {total-have} | cobertura: {have/total*100:.2f}%')
