#!/usr/bin/env python3
"""Build the offline Strong token/lexicon assets from STEPBible-Data.

Outputs:
  app/src/main/assets/strong_tokens.json   ref -> [{surface,strong,lemma,translit,morph,gloss}]
  app/src/main/assets/strong_lexicon.json  strong -> {original,translit,gloss,definition}
  app/src/main/assets/strong_sources.json  attribution/provenance

The resulting Android app remains offline; network is used only on the developer
machine while building the assets.
"""
from __future__ import annotations
import json,re,sys,hashlib,argparse
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
ASSET=ROOT/'app/src/main/assets'
FILES={
'TAGNT_Mat_Jhn.txt':'Translators%20Amalgamated%20OT%2BNT/TAGNT%20Mat-Jhn%20-%20Translators%20Amalgamated%20Greek%20NT%20-%20STEPBible.org%20CC-BY.txt',
'TAGNT_Act_Rev.txt':'Translators%20Amalgamated%20OT%2BNT/TAGNT%20Act-Rev%20-%20Translators%20Amalgamated%20Greek%20NT%20-%20STEPBible.org%20CC-BY.txt',
'TAHOT_Gen_Deu.txt':'Translators%20Amalgamated%20OT%2BNT/TAHOT%20Gen-Deu%20-%20Translators%20Amalgamated%20Hebrew%20OT%20-%20STEPBible.org%20CC%20BY.txt',
'TAHOT_Jos_Est.txt':'Translators%20Amalgamated%20OT%2BNT/TAHOT%20Jos-Est%20-%20Translators%20Amalgamated%20Hebrew%20OT%20-%20STEPBible.org%20CC%20BY.txt',
'TAHOT_Job_Sng.txt':'Translators%20Amalgamated%20OT%2BNT/TAHOT%20Job-Sng%20-%20Translators%20Amalgamated%20Hebrew%20OT%20-%20STEPBible.org%20CC%20BY.txt',
'TAHOT_Isa_Mal.txt':'Translators%20Amalgamated%20OT%2BNT/TAHOT%20Isa-Mal%20-%20Translators%20Amalgamated%20Hebrew%20OT%20-%20STEPBible.org%20CC%20BY.txt',
'TBESG.txt':'Lexicons/TBESG%20-%20Translators%20Brief%20lexicon%20of%20Extended%20Strongs%20for%20Greek%20-%20STEPBible.org%20CC%20BY.txt',
'TBESH.txt':'Lexicons/TBESH%20-%20Translators%20Brief%20lexicon%20of%20Extended%20Strongs%20for%20Hebrew%20-%20STEPBible.org%20CC%20BY.txt',
}
CACHE=ROOT/'tools'/'stepbible_cache'; CACHE.mkdir(parents=True,exist_ok=True)

def get(name):
    p=CACHE/name
    if not p.exists() or p.stat().st_size <= 1000:
        raise RuntimeError(f'Fonte ausente no cache: {p}. Execute fetch_stepbible_sources.py antes do build.')
    return p

def norm_ref(x):
    x=x.strip()
    x=re.sub(r'\[[^\]]*\]|\([^)]*\)|\{[^}]*\}$','',x)
    m=re.match(r'^([A-Za-z0-9]+)\.(\d+)\.(\d+)',x)
    if not m:return None
    return f'{m.group(1)}.{m.group(2)}.{m.group(3)}'

def parse_tagged(path, tokens):
    with path.open('r',encoding='utf-8-sig',errors='replace') as fh:
        for raw in fh:
            if not raw or raw.startswith('#') or raw.startswith('$'): continue
            cols=raw.split('\t')
            if len(cols)<4: continue
            first=cols[0]
            m=re.match(r'^([^#]+)#(\d+)',first)
            if not m: continue
            ref=norm_ref(m.group(1)); pos=int(m.group(2))
            if not ref: continue
            greek=cols[1].strip()
            english=cols[2].strip() if len(cols)>2 else ''
            dsm=cols[3].strip()
            # dStrong=Grammar, possibly with extra data
            strong=morph=''
            if '=' in dsm:
                strong,morph=dsm.split('=',1); strong=strong.strip(); morph=morph.strip()
            lemmagloss=cols[4].strip() if len(cols)>4 else ''
            lemma,gloss=(lemmagloss.split('=',1)+[''])[:2] if '=' in lemmagloss else (lemmagloss,'')
            surface=greek.split(' (',1)[0].strip()
            translit=''
            if ' (' in greek and greek.endswith(')'):
                translit=greek.rsplit(' (',1)[1][:-1]
            strong=re.sub(r'[^A-Za-z0-9]','',strong)
            if not strong: continue
            tokens.setdefault(ref,[]).append({'position':pos,'surface':surface,'strong':strong,'lemma':lemma.strip(),'translit':translit,'morph':morph,'gloss':gloss.strip() or english})
def parse_lexicon(path, lex):
    with path.open('r',encoding='utf-8-sig',errors='replace') as fh:
         for raw in fh:
             if not raw or raw.startswith('#') or raw.startswith('$'): continue
             cols=raw.split('\t')
             # Find first Strong-like field; keep the whole row for a robust fallback definition.
             idx=next((i for i,c in enumerate(cols) if re.fullmatch(r'[GH]\d{1,5}[A-Za-z0-9_-]*',c.strip())),None)
             if idx is None: continue
             code=cols[idx].strip()
             vals=[c.strip() for c in cols if c.strip()]
             if code not in lex:
                 lex[code]={"original":"","translit":"","gloss":"","definition":""}
             e=lex[code]
             if len(vals)>1 and not e['original']: e['original']=vals[1]
             if len(vals)>2 and not e['translit']: e['translit']=vals[2]
             if len(vals)>3 and not e['gloss']: e['gloss']=vals[3]
             if not e['definition']: e['definition']=' — '.join(vals[4:])[:1200]
ap=argparse.ArgumentParser()
ap.add_argument('--ref',default='master')
args=ap.parse_args()
ASSET.mkdir(parents=True,exist_ok=True)
tokens={}; lex={}
for n in list(FILES)[:6]: parse_tagged(get(n),tokens)
for n in list(FILES)[6:]: parse_lexicon(get(n),lex)
for ref in tokens: tokens[ref].sort(key=lambda x:x['position'])
(ASSET/'strong_tokens.json').write_text(json.dumps(tokens,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
(ASSET/'strong_lexicon.json').write_text(json.dumps(lex,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
# Build-time integrity metadata and per-book shards (useful for APK size/memory management).
shard_dir=ASSET/'strong_shards'; shard_dir.mkdir(parents=True,exist_ok=True)
by_book={}
for ref, rows in tokens.items(): by_book.setdefault(ref.split('.')[0],{})[ref]=rows
shards=[]
for book, data in sorted(by_book.items()):
    out=shard_dir/f'{book}.json'; payload=json.dumps(data,ensure_ascii=False,separators=(',',':')); out.write_text(payload,encoding='utf-8')
    shards.append({'book':book,'file':out.name,'references':len(data),'tokens':sum(len(v) for v in data.values()),'bytes':out.stat().st_size,'sha256':hashlib.sha256(payload.encode('utf-8')).hexdigest()})
manifest={'source':'STEPBible Data / Tyndale House Cambridge','license':'CC BY 4.0','attribution':'STEP Bible — Tyndale House Cambridge','repository':'https://github.com/STEPBible/STEPBible-Data','ref':args.ref,'cache_manifest':'tools/stepbible_cache/manifest.json','files':list(FILES.keys()),'token_references':len(tokens),'lexicon_entries':len(lex),'expected_jfaa_references':31104,'expected_books':66,'shards':shards}
(ASSET/'strong_sources.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
if manifest['token_references'] < 30000:
    print('AVISO: a base de tokens tem menos de 30.000 referências; verifique se todos os 8 arquivos foram baixados e processados.')
if manifest['lexicon_entries'] < 5000:
    print('AVISO: o léxico tem poucas entradas; verifique TBESG/TBESH.')
print(json.dumps(manifest,ensure_ascii=False,indent=2))
