#!/usr/bin/env python3
"""Validate the generated/import-ready Strong assets for the Android app.

Checks schema, duplicate positions, Strong-code format, reference shape and
lexicon/token consistency. It never invents missing data.
"""
from __future__ import annotations
import json, re, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ASSET = ROOT / 'app' / 'src' / 'main' / 'assets'
TOK = ASSET / 'strong_tokens.json'
LEX = ASSET / 'strong_lexicon.json'
SRC = ASSET / 'strong_sources.json'
SHARDS = ASSET / 'strong_shards'

errors=[]; warnings=[]
def load(p):
    try: return json.loads(p.read_text(encoding='utf-8'))
    except FileNotFoundError:
        warnings.append(f'{p.name}: arquivo ausente (opcional nesta versão)'); return None
    except Exception as e:
        errors.append(f'{p.name}: JSON inválido: {e}'); return None

tokens=load(TOK); lex=load(LEX); src=load(SRC)
if isinstance(tokens,dict):
    for ref, rows in tokens.items():
        if not re.fullmatch(r'[A-Za-z0-9À-ÿ ]+\s*\d+:\d+', ref) and not re.fullmatch(r'[A-Za-z0-9]+\.\d+\.\d+', ref):
            errors.append(f'Referência inválida: {ref}')
        if not isinstance(rows,list):
            errors.append(f'{ref}: tokens não são lista'); continue
        seen=set()
        for i,row in enumerate(rows):
            if isinstance(row,list):
                if len(row) >= 2 and str(row[1]).strip(): continue
                warnings.append(f'{ref}[{i}]: token legado sem Strong')
                continue
            if not isinstance(row,dict): errors.append(f'{ref}[{i}]: token não é objeto'); continue
            pos=row.get('position')
            if not isinstance(pos,int): errors.append(f'{ref}[{i}]: position inválida')
            elif pos in seen: errors.append(f'{ref}: posição duplicada {pos}')
            else: seen.add(pos)
            code=str(row.get('strong','')).strip()
            if code and not re.fullmatch(r'[GH]\d{1,5}[A-Za-z0-9_-]*',code):
                errors.append(f'{ref}[{i}]: Strong inválido: {code}')
            if not str(row.get('surface','')).strip(): warnings.append(f'{ref}[{i}]: surface vazia')
            if code and isinstance(lex,dict) and code not in lex:
                warnings.append(f'{ref}[{i}]: {code} não encontrado no léxico')
if isinstance(lex,dict):
    for code,entry in lex.items():
        if not re.fullmatch(r'[GH]\d{1,5}[A-Za-z0-9_-]*',code): errors.append(f'Léxico: Strong inválido: {code}')
        if not isinstance(entry,(dict,list,tuple)): errors.append(f'Léxico {code}: entrada inválida')
if isinstance(src,dict):
    for k in ('source','license','repository'):
        if not src.get(k): warnings.append(f'strong_sources.json: campo {k} ausente')

if isinstance(src,dict):
    expected=int(src.get('expected_jfaa_references',31104))
    expected_books=int(src.get('expected_books',66))
    if isinstance(src.get('shards'),list) and len(src['shards']) < expected_books:
        warnings.append(f"Cobertura de livros abaixo do alvo: {len(src['shards'])}/{expected_books} livros com shards")
    actual=len(tokens) if isinstance(tokens,dict) else 0
    if actual < expected:
        warnings.append(f'Cobertura abaixo do alvo: {actual}/{expected} referências')
    if SHARDS.exists():
        shard_count=len(list(SHARDS.glob('*.json')))
        if shard_count == 0: warnings.append('strong_shards existe, mas não contém arquivos .json')

print(f'Referências: {len(tokens) if isinstance(tokens,dict) else 0}')
print(f'Tokens: {sum(len(v) for v in tokens.values()) if isinstance(tokens,dict) else 0}')
print(f'Entradas do léxico: {len(lex) if isinstance(lex,dict) else 0}')
print(f'Avisos: {len(warnings)}')
print(f'Erros: {len(errors)}')
for x in warnings[:30]: print('WARN:',x)
for x in errors[:30]: print('ERROR:',x)
if errors: sys.exit(1)
