#!/usr/bin/env python3
"""Fetch the exact STEPBible-Data Strong sources used by the offline builder.

The script discovers files from the official repository tree and downloads them
to tools/stepbible_cache. It first tries GitHub's raw endpoint and falls back to
the Git Blob API (base64) for large files. A ref (branch/tag/commit) can be
pinned for reproducibility.
"""
from __future__ import annotations
import argparse, base64, hashlib, json, sys, time
from pathlib import Path
from urllib.parse import quote
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]
CACHE = ROOT / "tools" / "stepbible_cache"
CACHE.mkdir(parents=True, exist_ok=True)
TREE_API = "https://api.github.com/repos/STEPBible/STEPBible-Data/git/trees/{ref}?recursive=1"
BLOB_API = "https://api.github.com/repos/STEPBible/STEPBible-Data/git/blobs/{sha}"
RAW = "https://raw.githubusercontent.com/STEPBible/STEPBible-Data/{ref}/"
TARGETS = {
    "TAGNT_Mat_Jhn.txt": "TAGNT Mat-Jhn - Translators Amalgamated Greek NT - STEPBible.org CC-BY.txt",
    "TAGNT_Act_Rev.txt": "TAGNT Act-Rev - Translators Amalgamated Greek NT - STEPBible.org CC-BY.txt",
    "TAHOT_Gen_Deu.txt": "TAHOT Gen-Deu - Translators Amalgamated Hebrew OT - STEPBible.org CC BY.txt",
    "TAHOT_Jos_Est.txt": "TAHOT Jos-Est - Translators Amalgamated Hebrew OT - STEPBible.org CC BY.txt",
    "TAHOT_Job_Sng.txt": "TAHOT Job-Sng - Translators Amalgamated Hebrew OT - STEPBible.org CC BY.txt",
    "TAHOT_Isa_Mal.txt": "TAHOT Isa-Mal - Translators Amalgamated Hebrew OT - STEPBible.org CC BY.txt",
    "TBESG.txt": "TBESG - Translators Brief lexicon of Extended Strongs for Greek - STEPBible.org CC BY.txt",
    "TBESH.txt": "TBESH - Translators Brief lexicon of Extended Strongs for Hebrew - STEPBible.org CC BY.txt",
}

def get_json(url: str, timeout=180):
    req = Request(url, headers={"User-Agent":"EsbocoBiblicoApp-StrongBuilder/24","Accept":"application/vnd.github+json"})
    with urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))

def get_bytes(url: str, timeout=300):
    req = Request(url, headers={"User-Agent":"EsbocoBiblicoApp-StrongBuilder/24"})
    with urlopen(req, timeout=timeout) as r:
        return r.read()

def sha256(data): return hashlib.sha256(data).hexdigest()

def discover(ref):
    payload=get_json(TREE_API.format(ref=quote(ref,safe="")),120)
    if payload.get("truncated"):
        raise RuntimeError("GitHub retornou uma árvore truncada; use um commit/tag ou tente novamente.")
    blobs={x.get("path",""):x for x in payload.get("tree",[]) if x.get("type")=="blob"}
    out={}
    for key, filename in TARGETS.items():
        hits=[(p,v.get("sha")) for p,v in blobs.items() if p.rsplit("/",1)[-1]==filename]
        if len(hits)!=1:
            raise RuntimeError(f"{filename}: esperado 1 arquivo, encontrado {len(hits)}")
        out[key]={"path":hits[0][0],"sha":hits[0][1]}
    return out

def download_one(ref, meta, out):
    path, blob_sha=meta["path"],meta["sha"]
    # Raw is faster for most files.
    try:
        data=get_bytes(RAW.format(ref=quote(ref,safe=""))+quote(path,safe="/"),300)
        if len(data)>=1000:
            return data, "raw"
    except Exception:
        pass
    # Blob API is the large-file fallback and returns base64 content.
    payload=get_json(BLOB_API.format(sha=blob_sha),300)
    if payload.get("encoding")!="base64" or "content" not in payload:
        raise RuntimeError(f"Git Blob API não retornou conteúdo base64 para {path}")
    data=base64.b64decode(payload["content"])
    if len(data)<1000:
        raise RuntimeError(f"Arquivo suspeito/incompleto: {path} ({len(data)} bytes)")
    return data, "blob-api"

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--ref",default="master")
    ap.add_argument("--force",action="store_true")
    args=ap.parse_args()
    paths=discover(args.ref)
    manifest={"repository":"https://github.com/STEPBible/STEPBible-Data","ref":args.ref,"files":{}}
    for key,meta in paths.items():
        dest=CACHE/key
        if dest.exists() and dest.stat().st_size>=1000 and not args.force:
            data=dest.read_bytes()
            manifest["files"][key]={**meta,"bytes":len(data),"sha256":sha256(data),"cached":True}
            print(f"CACHE {key}: {len(data):,} bytes")
            continue
        last=None
        for attempt in range(1,4):
            try:
                data,method=download_one(args.ref,meta,dest)
                tmp=dest.with_suffix(dest.suffix+".part"); tmp.write_bytes(data); tmp.replace(dest)
                manifest["files"][key]={**meta,"bytes":len(data),"sha256":sha256(data),"cached":False,"method":method}
                print(f"OK {key}: {len(data):,} bytes ({method})")
                break
            except Exception as e:
                last=e
                if attempt<3: time.sleep(2*attempt)
        else:
            print(f"ERRO {key}: {last}",file=sys.stderr); return 3
    (CACHE/"manifest.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding="utf-8")
    print("\n8/8 fontes disponíveis.")
    return 0
if __name__=="__main__": raise SystemExit(main())
